"""
AI Smart Waste Management System - Application Package
Real-Time Waste Classification Using Deep Learning, Computer Vision & FastAPI.
"""

__version__ = "1.0.0"
